import { test, expect } from '@playwright/test';
test.use({ storageState: 'playwright/.auth/Flipkart2_Auth.json' });
test.use({
    launchOptions: {
        args: ['--deny-permission-prompts'],
    },
 });


 const TOKEN = '9271555988:AAFTbZTiiIGeL-YOM6-7GzAF0n1i13jxvaI';
const CHAT_ID = '-1004443840138';
test('Flipkart stock check', async ({ page }) => {
    while (true){

        await page.goto('https://www.flipkart.com/wishlist');
        while(true){
            try {
                await page.getByText('Load more items').click({timeout:5000})
                await page.waitForTimeout(5000)
            } catch (error) {
                break;
            }
        }
        // await page.pause()
        let listItems = await page.locator('[loading="lazy"]').all()
        console.log("listItems : " , listItems)
        if(listItems){
            for(let i=0;i<listItems.length;i++){
                const status = page
                .locator('[loading="lazy"]').nth(i)
                .locator('..')   // -> div.lWX0_T
                .locator('..')   // -> div (unnamed)
                .locator('..')   // -> div.tC8ZQS
                .locator('span');   // travel down to target
                try {
                    let contect = await status.textContent({timeout:5000})
                    console.log("contecnt  =  ", contect)
                } catch (error) {
                    const title = page
                    .locator('[loading="lazy"]').nth(i)
                    .locator('..')   // -> div.lWX0_T
                    .locator('..')   // -> div (unnamed)
                    .locator('..')
                    .locator('..')
                    .locator('..')
                    const href = await title.getAttribute('href');                    
                    if (href) {
                        const name = href.split('/p/')[0]                                                      
                        console.log(name);   
                        
                        let price = await title.locator('div').allTextContents()
                        console.log("price --> ",price[9])
                        await sendTelegramAlert(`Flipkart --> ${name} is in stock\nprice ${price[9]}`)
                    }
                }
            }
        }else{
            throw new Error("cart selection failed in playwright")
        }
    }
});




async function sendTelegramAlert(text:any) {
    await fetch(`https://api.telegram.org/bot${TOKEN}/sendMessage`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ chat_id: CHAT_ID, text }),
    });
    console.log("text ---> ", text)
}
