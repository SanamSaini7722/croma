import { test, expect } from '@playwright/test';
test.use({ storageState: 'playwright/.auth/chroma_Auth.json' });
test.use({
    launchOptions: {
        args: ['--deny-permission-prompts'],
    },
});
const TOKEN = '9271555988:AAFTbZTiiIGeL-YOM6-7GzAF0n1i13jxvaI';
const CHAT_ID = '-1004492357155';


const PRODUCT_URLS = [
    {
        name: "Apple iPhone 17 (256GB, Black)",
        link: "https://www.croma.com/apple-iphone-17-256gb-black-/p/317396"
    },
    {
        name: "Apple iPhone 17 (256GB, White)",
        link: "https://www.croma.com/apple-iphone-17-256gb-white-/p/317398"
    },
    {
        name: "Apple iPhone 17 (256GB, Mist Blue)",
        link: "https://www.croma.com/apple-iphone-17-256gb-mist-blue-/p/317400"
    },
    {
        name: "Apple iPhone 17 (256GB, Lavender)",
        link: "https://www.croma.com/apple-iphone-17-256gb-lavender-/p/317401"
    },
    {
        name: "Apple iPhone 17 (256GB, Sage)",
        link: "https://www.croma.com/apple-iphone-17-256gb-sage-/p/317403"
    },
    {
        name: "Croma 1000 Watts Dry Iron (Non-Stick Coated Soleplate, Blue)",
        link: "https://www.croma.com/croma-1000-watts-dry-iron-non-stick-coated-soleplate-blue-/p/316356"
    }
]

const THROTTLED_PRODUCT =
  "Croma 1000 Watts Dry Iron (Non-Stick Coated Soleplate, Blue)";
const THROTTLE_MS = 5 * 60 * 1000; // 5 minutes
let lastIronAlertAt = 0;

const pincodes = [125050]


test(`Chroma stock check`, async ({ page, context }) => {
    console.log("starting test")
    test.setTimeout(0)
    while(true){
        try {
            for(let i=0;i<PRODUCT_URLS.length;i++){
                console.log("opening url")
                await page.goto(PRODUCT_URLS[i].link);
                await page.waitForTimeout(1000)
                await page.keyboard.press('Space');
                await page.waitForTimeout(1000)
                const buyNowBtn = page.locator('button.buyNowBtn', { hasText: 'Buy Now' });
                try {
                    await buyNowBtn.first().waitFor({ state: 'visible', timeout: 2000 });
                    let price = "No Price"
                    try {
                        price = (
                            await page
                              .getByTestId('product-details')
                              .getByTestId('new-price')
                              .innerText({ timeout: 3000 })
                          ).trim();
                    } catch (error) {
                        
                    }

                    console.log(`${PRODUCT_URLS[i].name} is in stock — ${price}`);
                    const message = `${PRODUCT_URLS[i].name} is in stock\nPrice: ${price}\nlink -> ${PRODUCT_URLS[i].link} XXXXXXXX`;
                    if (PRODUCT_URLS[i].name === THROTTLED_PRODUCT) {
                      const now = Date.now();
                      if (now - lastIronAlertAt >= THROTTLE_MS) {
                        await sendTelegramAlert(message);
                        lastIronAlertAt = now;
                      } else {
                        console.log(`Skipping iron alert (throttled 5 min)`);
                      }
                    } else {
                      await sendTelegramAlert(message); // iPhones: instant
                    }
                } catch {
                    console.log(`${PRODUCT_URLS[i].name} is out of stock`);
                    // await sendTelegramAlert(`${PRODUCT_URLS[i].name} is out of stock`)
                  
                }     
            }
    

        } catch (error) {
    
        await sendTelegramAlert(`Automation Crashed`);            
        }
    }
    
});

async function sendTelegramAlert(text:any) {
    await fetch(`https://api.telegram.org/bot${TOKEN}/sendMessage`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ chat_id: CHAT_ID, text }),
    });
}
